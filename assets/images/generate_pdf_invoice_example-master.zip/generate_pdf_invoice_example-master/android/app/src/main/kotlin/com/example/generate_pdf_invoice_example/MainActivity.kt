package com.example.generate_pdf_invoice_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
