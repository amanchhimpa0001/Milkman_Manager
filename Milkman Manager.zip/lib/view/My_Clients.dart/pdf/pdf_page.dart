import 'dart:io';

import 'package:milkman_manager_app/view/My_Clients.dart/pdf/pdf_api.dart';

import 'package:pdf/widgets.dart' as pw;

class MyInvoice {
  static Future<File> generateInvoice() async {
    final pw.Document document = await pw.Document();

    document.addPage(pw.Page(
        // pageFormat: PdfPageFormat(width, height),
        margin: pw.EdgeInsets.all(30),
        build: (context) => pw.Column(children: [
              pw.Text('This is my first invoice',
                  style: pw.TextStyle(fontSize: 80))
            ])));

    return await PdfApi.saveDocument(document: document, name: 'name.pdf');
  }
}
