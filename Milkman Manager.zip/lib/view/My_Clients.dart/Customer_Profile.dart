import 'package:easy_date_timeline/easy_date_timeline.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:milkman_manager_app/dummy_widget/today_milktile.dart';
import 'package:milkman_manager_app/helpers/all_icons.dart';
import 'package:milkman_manager_app/helpers/all_image.dart';
import 'package:milkman_manager_app/helpers/color_sheet.dart';
import 'package:milkman_manager_app/helpers/text_theme.dart';
import 'package:milkman_manager_app/model/today_milkmodel.dart/today_mikl_model.dart';
import 'package:milkman_manager_app/view/My_Clients.dart/pdf/pdf_api.dart';

import 'package:milkman_manager_app/view/My_Clients.dart/pdf/pdf_page.dart';

class CustomerProfile extends StatelessWidget {
  const CustomerProfile({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 20,
        title: Text(
          "Customer Profile",
          style: GetTextTheme.fs14_regular,
        ),
        actions: [
          InkWell(
            onTap: () {},
            child: Text(
              "+ Add Payment",
              style: GetTextTheme.fs12_regular.copyWith(color: AppColors.blue),
              textAlign: TextAlign.center,
            ),
          ),
          Gap(10.h),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      border: Border.all(color: AppColors.primary)),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Will Smith",
                            style: GetTextTheme.fs24_medium
                                .copyWith(color: AppColors.primary),
                          ),
                          Column(
                            children: [
                              Text(
                                "Balance",
                                style: GetTextTheme.fs14_regular,
                              ),
                              Text(
                                "₹ 5,000",
                                style: GetTextTheme.fs16_medium,
                              )
                            ],
                          )
                        ],
                      ),
                      Gap(10.h),
                      Divider(),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: Icon(Icons.phone_android_rounded),
                        title: Text(
                          "+91 9991234511",
                          style: GetTextTheme.fs14_regular,
                        ),
                        trailing: Icon(
                          Icons.phone,
                          color: AppColors.primary,
                        ),
                      ),
                      ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: Icon(Icons.location_on_outlined),
                          title: Text(
                            "#12, New Rishi Nagar, Near Bus Stand, Hisar (Haryana)",
                            style: GetTextTheme.fs14_regular,
                          ),
                          trailing: Image.asset(
                            Appicons.address,
                            scale: 3,
                            color: AppColors.primary,
                          )),
                    ],
                  ),
                ),
                EasyDateTimeLine(
                  initialDate: DateTime.now(),
                  onDateChange: (selectedDate) {
                    //selectedDate the new date selected.
                  },
                  activeColor: const Color(0xffF8EDE2),
                  headerProps: const EasyHeaderProps(
                    dateFormatter: DateFormatter.monthOnly(),
                  ),
                  dayProps: const EasyDayProps(
                    // height: 56.0,
                    // width: 56.0,
                    dayStructure: DayStructure.dayStrDayNumMonth,
                    inactiveDayStyle: DayStyle(
                      decoration: BoxDecoration(
                          border: Border.fromBorderSide(
                              BorderSide(color: AppColors.greycolor))),
                      borderRadius: 10.0,
                      dayNumStyle: TextStyle(
                        fontSize: 18.0,
                      ),
                    ),
                    activeDayStyle: DayStyle(
                      dayNumStyle: TextStyle(
                        fontSize: 18.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                Gap(10.h),
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(color: AppColors.lightprimary),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Image.asset(
                        Getimage.milk,
                        scale: 3,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "53.6 Ltr",
                            style: GetTextTheme.fs20_medium,
                          ),
                          Text(
                            "Total Milk ",
                            style: GetTextTheme.fs10_regular,
                          ),
                          Gap(10),
                          Text(
                            "₹ 3112.00",
                            style: GetTextTheme.fs20_medium,
                          ),
                          Text(
                            "Total Bill ",
                            style: GetTextTheme.fs10_regular,
                          ),
                        ],
                      ),
                      Expanded(child: SizedBox()),
                      Column(
                        children: [
                          Text(
                            "Mar 2024 ",
                            style: GetTextTheme.fs14_medium,
                          ),
                          Gap(40.h),
                          InkWell(
                            onTap: () async {
                              final file = await MyInvoice.generateInvoice();
                              PdfApi.openFile(file.path);
                              // Appservices.pushto(context, pdf_data_all());
                            },
                            child: Text(
                              "View Bill",
                              style: GetTextTheme.fs12_regular
                                  .copyWith(color: AppColors.blue),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
                Gap(10),
                ListView.separated(
                    physics: NeverScrollableScrollPhysics(),
                    separatorBuilder: (context, index) => SizedBox(height: 10),
                    shrinkWrap: true,
                    itemCount: TodayMilkHelp.dailymilkdetailslist.length,
                    itemBuilder: (context, index) => Today_Milk_tile(
                          data: TodayMilkHelp.dailymilkdetailslist[index],
                        )),
                Gap(10),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
