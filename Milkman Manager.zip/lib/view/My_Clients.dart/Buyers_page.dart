import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:milkman_manager_app/helpers/app_services.dart';
import 'package:milkman_manager_app/helpers/color_sheet.dart';
import 'package:milkman_manager_app/helpers/text_theme.dart';
import 'package:milkman_manager_app/view/My_Clients.dart/Customer_Profile.dart';

class Buyers_page extends StatefulWidget {
  const Buyers_page({super.key});

  @override
  State<Buyers_page> createState() => _Buyers_pageState();
}

class _Buyers_pageState extends State<Buyers_page> {
  bool ischakvalue = false;
  bool ischakvalue2 = false;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Gap(10.h),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: InkWell(
              onTap: () {
                Appservices.pushto(context, CustomerProfile());
              },
              child: ListView.separated(
                separatorBuilder: (context, index) => SizedBox(
                  height: 10,
                ),
                itemCount: 3,
                shrinkWrap: true,
                // scrollDirection: Axis.horizontal,
                itemBuilder: (context, index) => Container(
                  padding: EdgeInsets.all(5),
                  decoration:
                      BoxDecoration(border: Border.all(color: AppColors.grey)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            padding: EdgeInsets.all(15),
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: AppColors.skyblue),
                            child: Text(
                              'WS',
                              style: GetTextTheme.fs12_bold
                                  .copyWith(color: AppColors.primary),
                            ),
                          ),
                          Gap(10.h),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(top: 3),
                                child: Row(
                                  children: [
                                    Text(
                                      'Will Smith',
                                      style: GetTextTheme.fs14_regular,
                                    ),
                                    Gap(10.h),
                                    Container(
                                        padding: EdgeInsets.only(
                                            left: 10,
                                            right: 10,
                                            top: 2,
                                            bottom: 2),
                                        decoration: BoxDecoration(
                                            color: AppColors.orange,
                                            borderRadius:
                                                BorderRadius.circular(20)),
                                        child: Text(
                                          'Individual',
                                          style: GetTextTheme.fs10_regular
                                              .copyWith(
                                                  color: AppColors.whiteColor),
                                        )),
                                  ],
                                ),
                              ),
                              Gap(5.h),
                              Text(
                                '+91 999*****11',
                                style: GetTextTheme.fs10_medium,
                              ),
                            ],
                          ),
                          Expanded(child: SizedBox()),
                          Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Icon(Icons.more_vert))
                        ],
                      ),
                      Gap(10),
                      Row(
                        children: [
                          Icon(Icons.location_on_outlined),
                          Gap(5),
                          Text(
                            "#12, New Rishi Nagar, Near Bus Stand,\nHisar(Haryana)",
                            style: GetTextTheme.fs12_regular,
                          ),
                          Gap(10.h),
                          GestureDetector(
                            onTap: () {
                              setState(() {
                                ischakvalue = !ischakvalue;
                              });
                            },
                            child: Container(
                              padding: EdgeInsets.only(
                                  left: 6, right: 6, top: 2, bottom: 2),
                              decoration: BoxDecoration(
                                  color: ischakvalue
                                      ? AppColors.primary
                                      : AppColors.whiteColor,
                                  border: Border.all(color: AppColors.grey),
                                  borderRadius: BorderRadius.only(
                                      bottomLeft: Radius.circular(20),
                                      topLeft: Radius.circular(20))),
                              child: Text(
                                "Mor",
                                style: GetTextTheme.fs10_regular.copyWith(
                                    color: ischakvalue
                                        ? AppColors.whiteColor
                                        : AppColors.blackColor),
                              ),
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              setState(() {
                                ischakvalue2 = !ischakvalue2;
                              });
                            },
                            child: Container(
                              padding: EdgeInsets.only(
                                  left: 6, right: 6, top: 2, bottom: 2),
                              decoration: BoxDecoration(
                                  color: ischakvalue2
                                      ? AppColors.primary
                                      : AppColors.whiteColor,
                                  border: Border.all(color: AppColors.grey),
                                  borderRadius: BorderRadius.only(
                                      bottomRight: Radius.circular(20),
                                      topRight: Radius.circular(20))),
                              child: Text(
                                "Eve",
                                style: GetTextTheme.fs10_regular.copyWith(
                                    color: ischakvalue2
                                        ? AppColors.whiteColor
                                        : AppColors.blackColor),
                              ),
                            ),
                          )
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
