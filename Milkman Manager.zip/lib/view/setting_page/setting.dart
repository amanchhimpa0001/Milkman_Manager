import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:milkman_manager_app/Utils/routs_name.dart';
import 'package:milkman_manager_app/authentication/login_page.dart';
import 'package:milkman_manager_app/componants/exptiontile.dart';
import 'package:milkman_manager_app/componants/textformfield.dart';
import 'package:milkman_manager_app/helpers/all_image.dart';
import 'package:milkman_manager_app/helpers/app_services.dart';
import 'package:milkman_manager_app/helpers/color_sheet.dart';
import 'package:milkman_manager_app/helpers/text_theme.dart';
import 'package:milkman_manager_app/view/My_Clients.dart/my_clients.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

class Setting extends StatelessWidget {
  const Setting({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Settings",
                  style: GetTextTheme.fs24_regular,
                ),
                Gap(10.h),
                leadinghideformfeild(
                  icon: Icons.search,
                  hintText: "Search...",
                  style: GetTextTheme.fs12_regular,
                  fillcolor: AppColors.tranceparent,
                ),
                Gap(10.h),
                Text(
                  "User Account",
                  style: GetTextTheme.fs16_regular
                      .copyWith(color: AppColors.primary),
                ),
                Row(
                  children: [
                    Expanded(
                      child: ListTile(
                          contentPadding: EdgeInsets.zero,
                          onTap: () {},
                          leading: Image.asset(Getimage.profileimg),
                          title: Text(
                            "John Doe",
                            style: GetTextTheme.fs14_medium,
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "user@example.com",
                                style: GetTextTheme.fs12_regular,
                              ),
                              Gap(5),
                            ],
                          ),
                          trailing: CircularPercentIndicator(
                            radius: 25.0,
                            lineWidth: 5.0,
                            animation: true,
                            percent: 0.7,
                            center: new Text(
                              "70%",
                              style: new TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 10.0),
                            ),
                            circularStrokeCap: CircularStrokeCap.round,
                            progressColor: Colors.green,
                          )),
                    ),
                    Gap(15),
                    Icon(Icons.keyboard_arrow_right_rounded)
                  ],
                ),
                Text(
                  "Business Account",
                  style: GetTextTheme.fs16_regular
                      .copyWith(color: AppColors.primary),
                ),
                Row(
                  children: [
                    Expanded(
                      child: ListTile(
                          contentPadding: EdgeInsets.zero,
                          onTap: () {},
                          leading: Image.asset(Getimage.homeimg),
                          title: Text(
                            "Kishan Milk Dairy",
                            style: GetTextTheme.fs14_medium,
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Tosham Road, Hisar",
                                style: GetTextTheme.fs12_regular,
                              ),
                              Gap(5),
                            ],
                          ),
                          trailing: CircularPercentIndicator(
                            radius: 25.0,
                            lineWidth: 5.0,
                            animation: true,
                            percent: 0.5,
                            center: new Text(
                              "60%",
                              style: new TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 10.0),
                            ),
                            circularStrokeCap: CircularStrokeCap.round,
                            progressColor: Colors.green,
                          )),
                    ),
                    Gap(15.h),
                    Icon(Icons.keyboard_arrow_right_rounded)
                  ],
                ),
                Text(
                  "Business Operations",
                  style: GetTextTheme.fs16_regular
                      .copyWith(color: AppColors.primary),
                ),
                exptiontilefuction(
                    cardname: 'Manage Pricing',
                    onPressed: () {
                      Navigator.pushNamed(context, Routesname.ManagePricing);
                    }),
                exptiontilefuction(
                    cardname: 'My Customers',
                    onPressed: () {
                      Appservices.pushto(context, MyClients_Buyer());
                    }),
                exptiontilefuction(
                    cardname: 'Transactions',
                    onPressed: () {
                      Navigator.pushNamed(context, Routesname.Transaction);
                    }),
                Text(
                  "Preferences",
                  style: GetTextTheme.fs16_regular
                      .copyWith(color: AppColors.primary),
                ),
                exptiontilefuction(
                    cardname: 'Notification Settings',
                    onPressed: () {
                      Navigator.pushNamed(
                          context, Routesname.Notification_Settings);
                    }),
                exptiontilefuction(
                    cardname: 'App Language',
                    onPressed: () {
                      Navigator.pushNamed(context, Routesname.App_Language);
                    }),
                Text(
                  "Legal and Policies",
                  style: GetTextTheme.fs16_regular
                      .copyWith(color: AppColors.primary),
                ),
                exptiontilefuction(
                  cardname: 'Privacy Policy',
                  onPressed: () {
                    Navigator.pushNamed(context, Routesname.PrivacyPolicy);
                  },
                ),
                exptiontilefuction(
                    cardname: 'Terms & Conditions',
                    onPressed: () {
                      Navigator.pushNamed(context, Routesname.TermsConditions);
                    }),
                exptiontilefuction(
                    cardname: 'Help & Support',
                    onPressed: () {
                      Navigator.pushNamed(context, Routesname.HelpSupport);
                    }),
                Padding(
                  padding: const EdgeInsets.only(right: 23),
                  child: InkWell(
                    onTap: () {},
                    child: ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(
                        'Refer & Earn',
                        style: GetTextTheme.fs14_regular,
                      ),
                      trailing: Icon(Icons.keyboard_arrow_right_rounded),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: InkWell(
                    onTap: () {},
                    child: ListTile(
                      visualDensity: VisualDensity.compact,
                      contentPadding: EdgeInsets.zero,
                      title: Text(
                        'Logout',
                        style: GetTextTheme.fs14_regular
                            .copyWith(color: AppColors.darkred),
                      ),
                      trailing: IconButton(
                          onPressed: () {
                            showDialog(
                              barrierDismissible: false,
                              context: context,
                              builder: (context) => Dialog(
                                insetPadding: EdgeInsets.symmetric(
                                  horizontal: 40,
                                ),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10)),
                                backgroundColor: AppColors.whiteColor,
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 20, vertical: 60),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      InkWell(
                                        onTap: () {
                                          Appservices.goback(context);
                                        },
                                        child: Text(
                                          "Cancal",
                                          style: GetTextTheme.fs16_regular,
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                      InkWell(
                                        onTap: () {
                                          Appservices.pushto(
                                              context, Login_page());
                                        },
                                        child: Text(
                                          "OK",
                                          style: GetTextTheme.fs16_regular
                                              .copyWith(
                                                  color: AppColors.darkred),
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                          icon: Icon(Icons.keyboard_arrow_right_rounded)),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
