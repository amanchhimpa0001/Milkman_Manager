import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:milkman_manager_app/componants/custum_elevated_btn.dart';
import 'package:milkman_manager_app/componants/radio_fun.dart';
import 'package:milkman_manager_app/componants/textformfield.dart';
import 'package:milkman_manager_app/helpers/all_icons.dart';
import 'package:milkman_manager_app/helpers/color_sheet.dart';
import 'package:milkman_manager_app/helpers/text_theme.dart';

class Add_Customer_Individual extends StatefulWidget {
  const Add_Customer_Individual({super.key});

  @override
  State<Add_Customer_Individual> createState() =>
      _Add_Customer_IndividualState();
}

class _Add_Customer_IndividualState extends State<Add_Customer_Individual> {
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _fullnameController = TextEditingController();

  final TextEditingController _AddressControllers = TextEditingController();

  final TextEditingController _CityControllers = TextEditingController();
  final TextEditingController _StateControllers = TextEditingController();
  final TextEditingController _StartDateControllers = TextEditingController();
  final TextEditingController _QuantityControllers = TextEditingController();

  String selectedValuemilk = "";
  String selectedValuecollect = "";
  String SelectCattle = "";
  String DeliverySchedule = "";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Gap(10.h),
                Text(
                  "Add Customer",
                  style: GetTextTheme.fs24_medium,
                ),
                Divider(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Radio_fun(
                        text: "Buyer",
                        onDone: (p0) {
                          setState(() {
                            selectedValuemilk = p0;
                          });
                        },
                        value: selectedValuemilk,
                      ),
                    ),
                    Expanded(
                      child: Radio_fun(
                        text: "Saller",
                        onDone: (p0) {
                          setState(() {
                            selectedValuemilk = p0;
                          });
                        },
                        value: selectedValuemilk,
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Radio_fun(
                        text: "Individual",
                        onDone: (p0) {
                          setState(() {
                            selectedValuecollect = p0;
                          });
                        },
                        value: selectedValuecollect,
                      ),
                    ),
                    Expanded(
                      child: Radio_fun(
                        text: "Dairy",
                        onDone: (p0) {
                          setState(() {
                            selectedValuecollect = p0;
                          });
                        },
                        value: selectedValuecollect,
                      ),
                    ),
                  ],
                ),
                Divider(),
                Gap(10.h),
                Text("Customer Profile", style: GetTextTheme.fs14_regular),
                Gap(15.h),
                Customtextformfilled(
                  prifixicon: Icons.person_2_outlined,
                  controller: _fullnameController,
                  hintText: "Username",
                  style: GetTextTheme.fs14_regular,
                  fillcolor: AppColors.tranceparent,
                ),
                Gap(15.h),
                Customtextformfilled(
                  prifixicon: Icons.phone_android,
                  controller: _phoneController,
                  hintText: "Phone Number",
                  style: GetTextTheme.fs14_regular,
                  fillcolor: AppColors.tranceparent,
                ),
                Gap(15.h),
                Customtextformfilled(
                  prifixicon: Icons.location_on_outlined,
                  controller: _AddressControllers,
                  hintText: "Address",
                  style: GetTextTheme.fs14_regular,
                  fillcolor: AppColors.tranceparent,
                ),
                Gap(15.h),
                Row(
                  children: [
                    Customtextformfilled(
                      isExpanded: true,
                      imageicon: Appicons.state,
                      controller: _CityControllers,
                      hintText: "City",
                      style: GetTextTheme.fs14_regular,
                      fillcolor: AppColors.tranceparent,
                    ),
                    Gap(10.h),
                    Customtextformfilled(
                      isExpanded: true,
                      imageicon: Appicons.state,
                      controller: _StateControllers,
                      hintText: "State",
                      style: GetTextTheme.fs14_regular,
                      fillcolor: AppColors.tranceparent,
                    ),
                  ],
                ),
                Gap(5.h),
                Divider(),
                Gap(5.h),
                Text("Requirements", style: GetTextTheme.fs14_regular),
                Gap(10.h),
                Row(
                  children: [
                    Customtextformfilled(
                      isExpanded: true,
                      imageicon: Appicons.datetime,
                      controller: _StartDateControllers,
                      hintText: "Start Date",
                      style: GetTextTheme.fs14_regular,
                      fillcolor: AppColors.tranceparent,
                    ),
                    Gap(10.h),
                    Customtextformfilled(
                      isExpanded: true,
                      imageicon: Appicons.Quantity,
                      controller: _QuantityControllers,
                      hintText: "Daily Quantity",
                      style: GetTextTheme.fs14_regular,
                      fillcolor: AppColors.tranceparent,
                    ),
                  ],
                ),
                Gap(10.h),
                Text(
                  'Select Cattle',
                  style: GetTextTheme.fs14_regular,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Radio_fun(
                        text: "Cow",
                        onDone: (p0) {
                          setState(() {
                            SelectCattle = p0;
                          });
                        },
                        value: SelectCattle,
                      ),
                    ),
                    Expanded(
                      child: Radio_fun(
                        text: "Buffalo",
                        onDone: (p0) {
                          setState(() {
                            SelectCattle = p0;
                          });
                        },
                        value: SelectCattle,
                      ),
                    ),
                  ],
                ),
                Gap(10.h),
                Text(
                  'Delivery Schedule',
                  style: GetTextTheme.fs14_regular,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Radio_fun(
                        text: "Morning",
                        onDone: (p0) {
                          setState(() {
                            DeliverySchedule = p0;
                          });
                        },
                        value: DeliverySchedule,
                      ),
                    ),
                    Expanded(
                      child: Radio_fun(
                        text: "Evening",
                        onDone: (p0) {
                          setState(() {
                            DeliverySchedule = p0;
                          });
                        },
                        value: DeliverySchedule,
                      ),
                    ),
                    Expanded(
                      child: Radio_fun(
                        text: "Both",
                        onDone: (p0) {
                          setState(() {
                            DeliverySchedule = p0;
                          });
                        },
                        value: DeliverySchedule,
                      ),
                    ),
                  ],
                ),
                CustomElevatedButton(
                    btnName: "Save Form",
                    onTap: () {},
                    foreground_clr: AppColors.whiteColor),
                Gap(27.h)
              ],
            ),
          ),
        ),
      ),
    );
  }
}
