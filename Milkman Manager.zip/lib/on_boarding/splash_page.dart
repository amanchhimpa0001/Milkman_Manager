import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:milkman_manager_app/authentication/login_page.dart';
import 'package:milkman_manager_app/helpers/all_image.dart';
import 'package:milkman_manager_app/helpers/app_config.dart';
import 'package:milkman_manager_app/helpers/app_services.dart';
import 'package:milkman_manager_app/helpers/color_sheet.dart';
import 'package:milkman_manager_app/helpers/text_theme.dart';

class SplashScreenView extends StatefulWidget {
  const SplashScreenView({super.key});

  @override
  State<SplashScreenView> createState() => _SplashScreenViewState();
}

class _SplashScreenViewState extends State<SplashScreenView> {
  @override
  void initState() {
    initalState();
    super.initState();
  }

  initalState() async {
    await Future.delayed(Duration(seconds: 2),
        () => Appservices.pushandremoveuntil(context, Login_page()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage(Getimage.splashimg), fit: BoxFit.cover)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Expanded(child: SizedBox()),
          Text(
            "MILKMAN’S\nMANAGER",
            style: GetTextTheme.fs35_bold.copyWith(color: AppColors.whiteColor),
          ),
          Gap(50.h),
          CircularProgressIndicator(
            color: AppColors.whiteColor,
          ),
          Expanded(child: SizedBox()),
          Image.asset(
            Getimage.cowimg,
          ),
          SizedBox(
            height: AppConfig.screenHeight * 0.12,
          )
        ],
      ),
    ));
  }
}
