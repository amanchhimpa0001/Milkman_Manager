import 'package:flutter/material.dart';
import 'package:milkman_manager_app/helpers/color_sheet.dart';
import 'package:milkman_manager_app/helpers/text_theme.dart';

// ignore: must_be_immutable
class Radio_fun extends StatefulWidget {
  String text;
  final Function(String)? onDone;

  String value;
  Radio_fun({super.key, required this.text, this.onDone, this.value = ""});

  @override
  State<Radio_fun> createState() => _Radio_funState();
}

class _Radio_funState extends State<Radio_fun> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: ListTile(
        contentPadding: EdgeInsets.zero,
        horizontalTitleGap: 0,
        title: Text(
          widget.text,
          style: GetTextTheme.fs14_regular,
        ),
        leading: Radio(
          value: widget.text,
          activeColor: AppColors.blackColor,
          groupValue: widget.value,
          onChanged: (value) {
            widget.onDone != null ? widget.onDone!(value.toString()) : null;
          },
        ),
      ),
    );
  }
}


// // ignore: must_be_immutable
// import 'package:flutter/material.dart';

// import 'package:milkman_manager_app/helpers/color_sheet.dart';

// class Radio_fun extends StatefulWidget {
//   List<String> data;
//   var selected;

//   final Function(String)? onDone;
//   Radio_fun({
//     super.key,
//     required this.selected,
//     required this.data,
//     required this.onDone,
//   });

//   @override
//   State<Radio_fun> createState() => _Radio_funState();
// }

// class _Radio_funState extends State<Radio_fun> {
//   var colour = '';

//   @override
//   void initState() {
//     super.initState();
//     setState(() {
//       colour = widget.selected;
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         ...List.generate(
//             widget.data.length,
//             (index) => ListTile(
//                   onTap: () {},
//                   leading: Radio(
//                     activeColor: AppColors.green,
//                     value: widget.data[index].toString(),
//                     groupValue: colour,
//                     onChanged: (value) {
//                       widget.onDone;
//                     },
//                   ),
//                   title: Text(widget.data[index]),
//                 )),
//       ],
//     );
//   }
// }
