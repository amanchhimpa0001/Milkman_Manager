import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:milkman_manager_app/componants/custum_elevated_btn.dart';
import 'package:milkman_manager_app/componants/radio_fun.dart';
import 'package:milkman_manager_app/componants/textformfield.dart';
import 'package:milkman_manager_app/helpers/all_icons.dart';
import 'package:milkman_manager_app/helpers/app_config.dart';
import 'package:milkman_manager_app/helpers/color_sheet.dart';
import 'package:milkman_manager_app/helpers/text_theme.dart';

class Sale_Milk extends StatefulWidget {
  const Sale_Milk({super.key});

  @override
  State<Sale_Milk> createState() => _Sale_MilkState();
}

class _Sale_MilkState extends State<Sale_Milk> {
  String selectedValuemilk = "";
  String selectedValueselingto = "";
  final TextEditingController _FatController = TextEditingController();
  final TextEditingController _QuantityController = TextEditingController();
  final TextEditingController _RateController = TextEditingController();
  List<String> usernamelist = [
    "Will Smith, #3 New Rishi Nagar Hisar",
    "Jordan, #11 New Rishi Nagar Hisar",
    "John Carter, #203 New Rishi Nagar Hisar",
    "Rambo, #1130 Sector-14A Hisar"
  ];
  var dropdownvalueusername;
  bool isactivename = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Sale Milk",
                style: GetTextTheme.fs24_medium,
              ),
              Divider(),
              InkWell(
                onTap: () => setState(() {
                  isactivename = !isactivename;
                }),
                child: Container(
                  padding: EdgeInsets.all(10),
                  width: double.infinity,
                  decoration: BoxDecoration(
                      border: Border.all(color: AppColors.grey),
                      borderRadius: BorderRadius.circular(40),
                      color: AppColors.tranceparent),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        dropdownvalueusername ?? "select one",
                        style: GetTextTheme.fs14_regular,
                      ),
                      Icon(Icons.keyboard_arrow_down)
                    ],
                  ),
                ),
              ),
              Visibility(
                  visible: isactivename,
                  child: Container(
                    alignment: Alignment.centerLeft,
                    width: AppConfig.screenWidth,
                    padding: EdgeInsets.symmetric(horizontal: 5),
                    decoration: BoxDecoration(
                        border: Border.all(color: AppColors.grey),
                        borderRadius: BorderRadius.circular(20),
                        color: AppColors.tranceparent),
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          ...List.generate(
                              usernamelist.length,
                              (index) => InkWell(
                                    onTap: () {
                                      setState(() {
                                        dropdownvalueusername =
                                            usernamelist[index];
                                        isactivename = false;
                                      });
                                    },
                                    child: Align(
                                      alignment: Alignment.centerLeft,
                                      child: RichText(
                                          text: TextSpan(
                                              text: usernamelist[index]
                                                  .split(",")
                                                  .first,
                                              style: GetTextTheme.fs14_regular
                                                  .copyWith(
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color:
                                                          AppColors.blackColor),
                                              children: [
                                            TextSpan(
                                              text: usernamelist[index]
                                                  .split(",")
                                                  .last,
                                              style: GetTextTheme.fs14_regular
                                                  .copyWith(
                                                      color:
                                                          AppColors.blackColor),
                                            ),
                                          ])),
                                    ),
                                  )),
                        ]),
                  )),
              Gap(15.h),
              Row(
                children: [
                  Customtextformfilled(
                    isExpanded: true,
                    imageicon: Appicons.fat,
                    controller: _FatController,
                    hintText: "Fat",
                    style: GetTextTheme.fs14_regular,
                    fillcolor: AppColors.tranceparent,
                  ),
                  Gap(10.h),
                  Customtextformfilled(
                    isExpanded: true,
                    imageicon: Appicons.Quantity,
                    controller: _QuantityController,
                    hintText: "Quantity",
                    style: GetTextTheme.fs14_regular,
                    fillcolor: AppColors.tranceparent,
                  ),
                ],
              ),
              Gap(10.h),
              Customtextformfilled(
                prifixicon: Icons.request_page_sharp,
                controller: _RateController,
                hintText: "Rate",
                style: GetTextTheme.fs14_regular,
                fillcolor: AppColors.tranceparent,
              ),
              Gap(10.h),
              Text(
                'Milk Type',
                style: GetTextTheme.fs14_regular,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Radio_fun(
                      text: "Cow",
                      onDone: (p0) {
                        setState(() {
                          selectedValuemilk = p0;
                        });
                      },
                      value: selectedValuemilk,
                    ),
                  ),
                  Expanded(
                    child: Radio_fun(
                      text: "Buffalo",
                      onDone: (p0) {
                        setState(() {
                          selectedValuemilk = p0;
                        });
                      },
                      value: selectedValuemilk,
                    ),
                  ),
                ],
              ),
              Gap(10.h),
              Text(
                'Salling to',
                style: GetTextTheme.fs14_regular,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Radio_fun(
                      text: "Individual",
                      onDone: (p0) {
                        setState(() {
                          selectedValueselingto = p0;
                        });
                      },
                      value: selectedValueselingto,
                    ),
                  ),
                  Expanded(
                    child: Radio_fun(
                      text: "Dairy",
                      onDone: (p0) {
                        setState(() {
                          selectedValueselingto = p0;
                        });
                      },
                      value: selectedValueselingto,
                    ),
                  ),
                ],
              ),
              CustomElevatedButton(
                  foreground_clr: AppColors.whiteColor,
                  btnName: "Sale Now",
                  onTap: () {}),
              // Radio_fun(
              //   text: "smsms",
              //   onDone: (p0) {},
              // )
            ],
          ),
        ),
      ),
    );
  }
}
