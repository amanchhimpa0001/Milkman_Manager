import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:milkman_manager_app/helpers/color_sheet.dart';
import 'package:milkman_manager_app/helpers/text_theme.dart';
import 'package:milkman_manager_app/model/today_milkmodel.dart/today_mikl_model.dart';

// ignore: must_be_immutable
class Today_Milk_tile extends StatelessWidget {
  Today_Milk_tile({super.key, required this.data});
  TodayMilkModel data;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(left: 10, right: 10, top: 5, bottom: 5),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppColors.grey)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            padding: EdgeInsets.all(5),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                border: Border.all(color: AppColors.primary)),
            child: Column(
              children: [
                Text(
                  data.week,
                  style: GetTextTheme.fs14_regular
                      .copyWith(color: AppColors.greycolor),
                ),
                Gap(10),
                Text(
                  data.date,
                  style: GetTextTheme.fs16_regular,
                )
              ],
            ),
          ),
          Column(
            children: [
              Text(
                'Fat',
                style: GetTextTheme.fs14_regular
                    .copyWith(color: AppColors.greycolor),
              ),
              Gap(10.h),
              Text(
                data.fat,
                style: GetTextTheme.fs16_medium,
              ),
            ],
          ),
          Column(
            children: [
              Text(
                'Rate',
                style: GetTextTheme.fs14_regular
                    .copyWith(color: AppColors.greycolor),
              ),
              Gap(10.h),
              Text(
                data.rate,
                style: GetTextTheme.fs16_medium,
              ),
            ],
          ),
          Column(
            children: [
              Text(
                'Qty',
                style: GetTextTheme.fs14_regular
                    .copyWith(color: AppColors.greycolor),
              ),
              Gap(10.h),
              Text(
                data.Qty,
                style: GetTextTheme.fs16_medium,
              ),
            ],
          ),
          Column(
            children: [
              Text(
                'Total',
                style: GetTextTheme.fs14_regular
                    .copyWith(color: AppColors.greycolor),
              ),
              Gap(10.h),
              Text(
                data.totalrupess,
                style:
                    GetTextTheme.fs16_medium.copyWith(color: AppColors.primary),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
