class Routesname {
  static const String SplashScreenView = "SplashScreenView";
  static const String Login_page = "Login_page";
  static const String Sign_up_page = "Sign_up_page";
  static const String DashBorad = "DashBorad";
  static const String Receive_Milk = "Receive_Milk";
  static const String Sale_Milk = "Sale_Milk";
  static const String ManagePricing = "ManagePricing";
  static const String Transaction = "Transaction";
  static const String App_Language = "App_Language";
  static const String Notification_Settings = "Notification_Settings";
  static const String PrivacyPolicy = "PrivacyPolicy";
  static const String TermsConditions = "TermsConditions";
  static const String HelpSupport = "HelpSupport";
}
