import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:milkman_manager_app/Utils/routs_name.dart';
import 'package:milkman_manager_app/componants/custum_elevated_btn.dart';
import 'package:milkman_manager_app/componants/radio_fun.dart';
import 'package:milkman_manager_app/componants/successfull_dailog.dart';
import 'package:milkman_manager_app/componants/textformfield.dart';
import 'package:milkman_manager_app/helpers/all_icons.dart';

import 'package:milkman_manager_app/helpers/color_sheet.dart';
import 'package:milkman_manager_app/helpers/text_theme.dart';

class Sign_up_page extends StatefulWidget {
  const Sign_up_page({super.key});

  @override
  State<Sign_up_page> createState() => _Sign_up_pageState();
}

class _Sign_up_pageState extends State<Sign_up_page> {
  bool colorchange = false;
  String Selectform = "";
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _fullnameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _ganderControllers = TextEditingController();
  final TextEditingController _BusinessNameControllers =
      TextEditingController();
  final TextEditingController _BusinessAddressControllers =
      TextEditingController();
  final TextEditingController _CityControllers = TextEditingController();
  final TextEditingController _StateControllers = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Gap(10.h),
                Text(
                  "Registration",
                  style: GetTextTheme.fs24_medium,
                ),
                Gap(10.h),
                Text(
                  "Fill the below form to get registered with Milkman’s Manager. We may send a confirmation text message on your phone number for verification purpose.",
                  style: GetTextTheme.fs12_regular
                      .copyWith(color: AppColors.blackColor),
                ),
                Gap(10.h),
                Divider(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Radio_fun(
                        text: "Individual",
                        onDone: (p0) {
                          setState(() {
                            Selectform = p0;
                          });
                        },
                        value: Selectform,
                      ),
                    ),
                    Expanded(
                      child: Radio_fun(
                        text: "Dairy",
                        onDone: (p0) {
                          setState(() {
                            Selectform = p0;
                          });
                        },
                        value: Selectform,
                      ),
                    ),
                  ],
                ),
                Text('Personal Information', style: GetTextTheme.fs14_regular),
                Gap(15.h),
                Customtextformfilled(
                  prifixicon: Icons.person_2_outlined,
                  controller: _fullnameController,
                  hintText: "Username",
                  style: GetTextTheme.fs14_regular,
                  fillcolor: AppColors.tranceparent,
                ),
                Gap(15.h),
                Customtextformfilled(
                  prifixicon: Icons.phone_android,
                  controller: _phoneController,
                  hintText: "Phone",
                  style: GetTextTheme.fs14_regular,
                  fillcolor: AppColors.tranceparent,
                ),
                Gap(15.h),
                Customtextformfilled(
                  prifixicon: Icons.email_outlined,
                  controller: _emailController,
                  hintText: "Email (optional)",
                  style: GetTextTheme.fs14_regular,
                  fillcolor: AppColors.tranceparent,
                ),
                Gap(15.h),
                Customtextformfilled(
                  imageicon: Appicons.gander,
                  controller: _ganderControllers,
                  hintText: "Gander",
                  style: GetTextTheme.fs14_regular,
                  fillcolor: AppColors.tranceparent,
                ),
                Gap(5.h),
                Divider(),
                Gap(5.h),
                Text('Business Information', style: GetTextTheme.fs14_regular),
                Gap(10.h),
                Customtextformfilled(
                  imageicon: Appicons.businessname,
                  controller: _BusinessNameControllers,
                  hintText: "Business Name",
                  style: GetTextTheme.fs14_regular,
                  fillcolor: AppColors.tranceparent,
                ),
                Gap(15.h),
                Customtextformfilled(
                  imageicon: Appicons.address,
                  controller: _BusinessAddressControllers,
                  hintText: "Business Address",
                  style: GetTextTheme.fs14_regular,
                  fillcolor: AppColors.tranceparent,
                ),
                Gap(15.h),
                Row(
                  children: [
                    Customtextformfilled(
                      isExpanded: true,
                      imageicon: Appicons.state,
                      controller: _CityControllers,
                      hintText: "City",
                      style: GetTextTheme.fs14_regular,
                      fillcolor: AppColors.tranceparent,
                    ),
                    Gap(10.h),
                    Customtextformfilled(
                      isExpanded: true,
                      imageicon: Appicons.state,
                      controller: _StateControllers,
                      hintText: "State",
                      style: GetTextTheme.fs14_regular,
                      fillcolor: AppColors.tranceparent,
                    ),
                  ],
                ),
                CheckboxListTile.adaptive(
                  checkColor: Colors.black,
                  activeColor: Colors.white,
                  side: MaterialStateBorderSide.resolveWith((states) {
                    if (states.contains(MaterialState.pressed)) {
                      return BorderSide(color: Colors.black);
                    } else {
                      return BorderSide(color: Colors.black, width: 2);
                    }
                  }),
                  value: colorchange,
                  checkboxShape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(6)),
                  visualDensity: VisualDensity(horizontal: -4),
                  contentPadding: EdgeInsets.zero,
                  controlAffinity: ListTileControlAffinity.leading,
                  title: RichText(
                      text: TextSpan(children: [
                    TextSpan(
                        text: "By Logging in you agreed ",
                        style: GetTextTheme.fs14_regular
                            .copyWith(color: AppColors.blackColor)),
                    TextSpan(
                        text: "to our terms of services and privacy policy",
                        style: GetTextTheme.fs14_medium
                            .copyWith(color: AppColors.blackColor)),
                  ])),
                  onChanged: (value) => setState(() {
                    colorchange = value!;
                  }),
                ),
                CustomElevatedButton(
                    peddingv: 16,
                    foreground_clr: AppColors.whiteColor,
                    btnName: "Register",
                    onTap: () {
                      showDialog(
                          barrierDismissible: false,
                          context: context,
                          builder: (context) =>
                              Registration_successful_dailog());
                    }),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("Already have an account?",
                        style: GetTextTheme.fs12_medium),
                    TextButton(
                        onPressed: () {
                          Navigator.pushNamed(context, Routesname.Login_page);
                        },
                        child: Text("Login Here",
                            style: GetTextTheme.fs12_bold
                                .copyWith(color: AppColors.primary)))
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
