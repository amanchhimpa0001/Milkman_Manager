class Appicons {
  static const String address = "assets/icons/address.png";
  static const String businessname = "assets/icons/businessname.png";
  static const String gander = "assets/icons/gander.png";
  static const String state = "assets/icons/state.png";
  static const String fat = "assets/icons/fat.png";
  static const String filter = "assets/icons/filter.png";
  static const String serach = "assets/icons/serach.png";
  static const String volit = "assets/icons/volit.png";
  static const String Rate = "assets/icons/Rate.png";
  static const String Quantity = "assets/icons/Quantity.png";
  static const String notifation = "assets/icons/notifation.png";
  static const String recivemlik = "assets/icons/recivemlik.png";
  static const String salemilk = "assets/icons/salemilk.png";
  static const String maltipalperson = "assets/icons/maltipalperson.png";

  static const String dashborad = "assets/icons/dashborad.png";
  static const String seeting = "assets/icons/seeting.png";
  static const String datetime = "assets/icons/datetime.png";
  static const String accountdelete = "assets/icons/accountdelete.png";
  static const String customer = "assets/icons/customer.png";
  static const String info = "assets/icons/info.png";
  static const String whatsapp = "assets/icons/whatsapp.png";
}
