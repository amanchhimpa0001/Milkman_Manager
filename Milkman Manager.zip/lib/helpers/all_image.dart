class Getimage {
  static String splashimg = "assets/images/splashimg.png";
  static String cowimg = "assets/images/cowimg.png";
  static String login_background = "assets/images/login_background.png";
  static String successful = "assets/images/successful.png";
  static String profileimg = "assets/images/profileimg.png";
  static String graphimg = "assets/images/graphimg.png";
  static String homeimg = "assets/images/homeimg.png";
  static String milk = "assets/images/milk.png";
}
