class AppConfig {
  static const double screenWidth = 393;
  static const double screenHeight = 852;
}
